# -*- coding: utf-8 -*-
"""把多文件版 AutoGrader 内联打包成单文件 HTML。

用法：
    cd autograder && python3 build-single.py

产物：与本目录同级的 `AutoGrader-单文件版.html`
（CSS 与全部 JS 已内联，双击即用，不依赖 assets/ 目录）

内联格式（与 assets 目录一一对应，可被 _recon/unbuild.py 反向拆分）：
    <link rel="stylesheet" href="assets/css/main.css">
        -> <style>\\n{css}\\n</style>
    <script src="assets/js/x.js"></script>
        -> <script>\\n/* ===== x.js ===== */\\n{js}\\n</script>
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ENTRY = ROOT / "index.html"
OUT = ROOT.parent / "AutoGrader-单文件版.html"

CSS_RE = re.compile(r'<link\s+rel="stylesheet"\s+href="(assets/css/[^"]+)"\s*/?>')
JS_RE = re.compile(r'<script\s+src="(assets/js/[^"]+)"></script>')


def read_text(rel: str) -> str:
    p = ROOT / rel
    if not p.exists():
        sys.exit("[ERROR] 缺少文件：%s" % p)
    # 统一换行 + 末尾保留单个换行，保证跨平台打包产物一致
    return p.read_text(encoding="utf-8").replace("\r\n", "\n").rstrip("\n") + "\n"


def main() -> None:
    if not ENTRY.exists():
        sys.exit("[ERROR] 找不到 index.html：%s" % ENTRY)
    html = ENTRY.read_text(encoding="utf-8").replace("\r\n", "\n")

    stats = {"css": 0, "js": 0}

    def css_sub(m):
        css = read_text(m.group(1))
        stats["css"] += 1
        return "<style>\n%s\n</style>" % css

    def js_sub(m):
        rel = m.group(1)
        name = Path(rel).name
        js = read_text(rel)
        # JS 里若出现 </script> 会提前终止脚本块，转义后语义等价
        js = js.replace("</script>", "<\\/script>")
        stats["js"] += 1
        return "<script>\n/* ===== %s ===== */\n%s\n</script>" % (name, js)

    html = CSS_RE.sub(css_sub, html)
    html = JS_RE.sub(js_sub, html)

    leftover = CSS_RE.findall(html) + JS_RE.findall(html)
    if leftover:
        sys.exit("[ERROR] 以下引用未被内联（检查路径/引号）：%s" % leftover)

    OUT.write_text(html, encoding="utf-8", newline="")
    print("打包完成：%s" % OUT)
    print("  内联 CSS %d 个 · JS %d 个 · 共 %d 字节" % (stats["css"], stats["js"], len(html.encode("utf-8"))))


if __name__ == "__main__":
    main()
